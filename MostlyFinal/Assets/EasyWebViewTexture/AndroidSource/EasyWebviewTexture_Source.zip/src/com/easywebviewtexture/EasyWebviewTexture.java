package com.easywebviewtexture;



import java.util.ArrayList;

import java.util.List;

import android.app.ActionBar.LayoutParams;
import android.app.Activity;
import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Canvas;
import android.graphics.SurfaceTexture;
import android.opengl.GLES20;

import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.View;

import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebSettings.PluginState;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

class WebViewCustom extends WebView {

	private int 		scrollL;
	private int 		scrollT;
	
	public Surface m_Surface = null;
	public int m_iWidth = 1080;
	public int m_iHeight = 1920;
	public long m_iPrevTime = 0;
	
	public static List<MotionEvent> m_event = new ArrayList<MotionEvent>();;
	public static List<MotionEvent> m_eventSwap = new ArrayList<MotionEvent>();;
	public boolean[] m_bUse;
	public List<MotionEvent> m_eventSelf  = new ArrayList<MotionEvent>();;
	
	public String name = "main";
	public FrameLayout m_framelayout = null;
	public boolean m_bTouch = false;
	public long downTime = 0;
	public boolean m_bUpdate= false;

	public boolean m_bSync = false;

	

	public WebViewCustom(Context context) {
		
		super(context);
		// TODO Auto-generated constructor stub
		
		
		
		
		
	}
	

	@Override	 
	public boolean onTouchEvent(MotionEvent event) {
		
		
		if(m_bTouch == false)
		{
			m_event.add(event);
		}
	
		if(m_bTouch == false)
		{
			return true;
		}
		else
		{
			return super.onTouchEvent(event);
		}
		
	}
	 
	   @Override
	   protected void onScrollChanged(int l, int t, int oldl, int oldt)
	   {
	      super.onScrollChanged(l, t, oldl, oldt);
	      scrollL = l;
	      scrollT = t;
	   }
	   
	   
	 
	   @Override 
	   protected void onDraw( Canvas canvas ) { 

		   if( m_iPrevTime == 0)
		   {
			   m_iPrevTime =   System.currentTimeMillis();
		   }
		   
		   if((  System.currentTimeMillis() - m_iPrevTime ) < 33)
		   {
			   return;
		   }
		   else
		   {
			   m_iPrevTime = System.currentTimeMillis() ;
		   }
		  
		   m_bUpdate = true;
		   if ( m_Surface != null ) { 
	
			 
	            Canvas surfaceCanvas = null;
				try {
					
					surfaceCanvas = m_Surface.lockCanvas( null );
					surfaceCanvas.save();
					surfaceCanvas.translate(-scrollL, -scrollT);
					super.onDraw( surfaceCanvas );
					surfaceCanvas.restore();

					m_Surface.unlockCanvasAndPost( surfaceCanvas );  

				
					
					
				} catch (IllegalArgumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (android.view.Surface.OutOfResourcesException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} // Android canvas from surface
				 // Android canvas from surface 
				   
	           } 
		   

		   
		   //super.onDraw( canvas );
		 
	        
		   }
	   
	  

	
	
}




public class EasyWebviewTexture 
{
	
	private static FrameLayout m_framelayout = null;

	public static Activity	m_UnityActivity = null;
	

	
   	
   	private int				m_iUnityTextureID = -1;
	private int				m_iSurfaceTextureID = -1;
	
   	private SurfaceTexture	m_SurfaceTexture = null;
	private Surface			m_Surface = null;
	private int 			m_iNativeMgrID;
	private WebViewCustom 	m_WebView = null;
	
	private int				m_iWidth;
	private int				m_iHeight;
	private int 			m_iScreenWidth;
	private int  			m_iScreenHeight;
	
	private boolean 		m_bInit = false;
	
	
 
   	public native int InitApplication(AssetManager assetManager);
	public native void QuitApplication();
	public native void InitView();
	public native void ReleaseView();
	public native void SetWindowSize(int iWidth,int iHeight,int iUnityTextureID);
	public native void RenderScene(float [] fValue, int iTextureID,int iUnityTextureID);
	public native void SetManagerID(int iID);
	public native int GetManagerID();
	public native int InitExtTexture();
	
	private static final int GL_TEXTURE_EXTERNAL_OES = 0x8D65;
	
	static
	{
		 System.loadLibrary("BlueDoveMediaRender_Webview");
	}
	
	
	public void UnInit()
	{
		m_bInit = false;
		m_UnityActivity.runOnUiThread(new Runnable() {public void run() {
			
			
			if(m_WebView != null)
			{
				m_framelayout.removeView(m_WebView);
				WebViewCustom temp = m_WebView;
				m_WebView = null;
				temp.destroy();
			
			}

		}});
		
		
	}
	
	public void Init()
	{
		
		
		UnInit();
		
		m_UnityActivity.runOnUiThread(new Runnable() {public void run() {

			m_WebView = new WebViewCustom(m_UnityActivity);
			m_WebView.setVisibility(View.GONE);
			m_WebView.setFocusable(true);
			m_WebView.setFocusableInTouchMode(true);

			m_framelayout.addView(m_WebView, new FrameLayout.LayoutParams(
					LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT,
					Gravity.NO_GRAVITY));
			
		
			m_WebView.setWebChromeClient(new WebChromeClient() {
				
				
				
			});
			
			
			
			
			m_WebView.setWebViewClient(new WebViewClient() {
			
				public boolean shouldOverrideUrlLoading(WebView view, String url) {
					//Log.e("unity",url);
			          view.loadUrl(url);
			          return true;
			           }}); 
				
		
		

			WebSettings webSettings = m_WebView.getSettings();
			webSettings.setSupportZoom(false);
			webSettings.setJavaScriptEnabled(true);
			webSettings.setSupportMultipleWindows(true);
			webSettings.setPluginState(PluginState.ON);
	
			webSettings.setRenderPriority(WebSettings.RenderPriority.HIGH);
			webSettings.setCacheMode(WebSettings.LOAD_NO_CACHE);

			String databasePath = m_WebView.getContext().getDir("databases", Context.MODE_PRIVATE).getPath(); 
			webSettings.setDatabaseEnabled(true);
			webSettings.setDomStorageEnabled(true);
			webSettings.setDatabasePath(databasePath); 
			webSettings.setSupportMultipleWindows(false);
			webSettings.setJavaScriptCanOpenWindowsAutomatically(true);


			
			m_WebView.setVerticalScrollBarEnabled(false);
			m_WebView.setHorizontalScrollBarEnabled(false);
		
			m_WebView.setLongClickable(false);
			
			m_WebView.setOnLongClickListener(new View.OnLongClickListener() {

	            public boolean onLongClick(View v) {
	                return true;
	            }
	            
	         
	        });
			
			m_bInit = true;

		}});

		
	}

	




	public void Destroy()
	{
		if(m_iSurfaceTextureID != -1)
		{
			int [] textures = new int[1];
			textures[0] = m_iSurfaceTextureID;
			GLES20.glDeleteTextures(1, textures, 0);
			m_iSurfaceTextureID = -1;
		}
		
		SetManagerID(m_iNativeMgrID);
		QuitApplication();
		
		UnInit();
		
		
	}
	
	public void UnLoad()
	{
		
		if(m_Surface != null)
		{
			if(m_WebView != null)
				m_WebView.m_Surface = null;
			
			m_Surface.release();
			m_Surface = null;
			
			
		}
		
		if(m_SurfaceTexture != null)
		{
			m_SurfaceTexture.release();
			m_SurfaceTexture = null;
		}
		
		if(m_iSurfaceTextureID != -1)
		{
			int [] textures = new int[1];
			textures[0] = m_iSurfaceTextureID;
			GLES20.glDeleteTextures(1, textures, 0);
			m_iSurfaceTextureID = -1;
		}
	}

	
	public boolean Load(final String strLoadUrl)
	{
		if(m_bInit == false)
			return false;
		
		if(m_WebView == null)
			return false;
			
		UnLoad();
		
		if(m_iSurfaceTextureID == -1)
		{
			m_iSurfaceTextureID = InitExtTexture();
		}
		
		
		m_SurfaceTexture = new SurfaceTexture(m_iSurfaceTextureID);
		m_SurfaceTexture.setDefaultBufferSize(m_iWidth,m_iHeight);
		m_Surface = new Surface(m_SurfaceTexture);
		m_WebView.m_Surface = m_Surface;
		m_WebView.m_framelayout = m_framelayout;
		
		m_UnityActivity.runOnUiThread(new Runnable() {					

			@Override

			public void run() {

				
				if(m_WebView != null)
				{
					
					m_WebView.loadUrl(strLoadUrl); 
				
					
				}
				
			}

		});
		
	

		
		

		m_framelayout.setOnTouchListener(new View.OnTouchListener() { 
			
			
		
	        @Override
	        public boolean onTouch(View v, MotionEvent event) {
	        	
	        	if( m_WebView != null)
	        	{
	        		if(m_WebView.m_bTouch == false)
	        		{
	        			m_WebView.m_event.add(event);
	        		}


	        	}
	        	
	        	return true; 
	        }
		});
		
	

		
		SetVisible(true);
	
		return true;
	}
	
	public void GoBack()
	{
		m_UnityActivity.runOnUiThread(new Runnable() {					

			@Override

			public void run() {

				
				if(m_WebView != null)
				{
					
					m_WebView.goBack();
				
					
				}
				
			}

		});
		
	}
	
	public void GoForward()
	{
		m_UnityActivity.runOnUiThread(new Runnable() {					

			@Override

			public void run() {

				
				if(m_WebView != null)
				{
					
					m_WebView.goForward();
				
					
				}
				
			}

		});
		
		
	}
	
	public void UpdateVideoTexture()
	{
		if(m_WebView == null)
			return;
		
		if(m_WebView.m_iPrevTime == 0)
			return;
		
		if(m_WebView.m_bUpdate == false)
			return;
		else
			m_WebView.m_bUpdate = false;
			
		


			if(m_SurfaceTexture != null)
			{
			

		
				SetManagerID(m_iNativeMgrID);
				m_SurfaceTexture.updateTexImage();
			
				
				
				float [] mMat = new float[16];
				m_SurfaceTexture.getTransformMatrix(mMat);
			
				RenderScene(mMat,m_iSurfaceTextureID,m_iUnityTextureID);
				
				

			}
			else
			{
				float [] mMat = new float[16];
				RenderScene(mMat,-1,m_iUnityTextureID);
			}
				
			
		
		
		
		
				
			
	}
	
	public void SetUnityTexture(int iTextureID)
	{
		m_iUnityTextureID = iTextureID;
		SetManagerID(m_iNativeMgrID);
		
	}
	
	
	public void SetUnityActivity(Activity activity)
    {
			
			m_UnityActivity = activity;
			m_iNativeMgrID = InitApplication(m_UnityActivity.getAssets());
			

			m_UnityActivity.runOnUiThread(new Runnable() {public void run() {

				if (m_framelayout == null) {
					m_framelayout = new FrameLayout(m_UnityActivity);
					m_UnityActivity.addContentView(m_framelayout, new LayoutParams(
						LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT));
					m_framelayout.setFocusable(true);
					m_framelayout.setFocusableInTouchMode(true);
				}

			}});
		
	
    }
	
	public void SetVisible( final boolean bValue)
	{

		m_UnityActivity.runOnUiThread(new Runnable() {public void run() {

			if (bValue) {
				m_WebView.setVisibility(View.VISIBLE);
				m_framelayout.requestFocus();
					m_WebView.requestFocus();
			} else {
				m_WebView.setVisibility(View.GONE);
			}

		}});
	}
	
	public void SetMargins(int iLeft, int iTop, int iRight, int iBottom)
	{
		final FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
			LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT,
				Gravity.NO_GRAVITY);
		params.setMargins(iLeft, iTop, iRight, iBottom);

		m_UnityActivity.runOnUiThread(new Runnable() {public void run() {

			m_WebView.setLayoutParams( params );
		
		}});
	}
	

	public void SetScreenSize(int iWidth,int iHeight)
	{
		m_iScreenWidth = iWidth;
		m_iScreenHeight = iHeight;
	}

	public void SetWindowSize(int iWidth,int iHeight)
	{
		SetManagerID(m_iNativeMgrID);
		m_iWidth = iWidth;
		m_iHeight = iHeight;
		
		if(m_WebView != null){
			m_WebView.m_iWidth = iWidth;
			m_WebView.m_iHeight = iHeight;
			
		}
		
		//Nexus7 POT Texture
		SetWindowSize(2048,2048,m_iUnityTextureID );
		
		Init();
		
		SetMargins(0,0,m_iScreenWidth - m_iWidth,m_iScreenHeight - m_iHeight);
		
	}
	
	public int GetTouchCount()
	{
		
		if(m_WebView != null)
		{
			if(m_WebView.m_bSync == true)
				return 0;
			
			return m_WebView.m_eventSwap.size();
		}
		
		return 0;
	}
	
	public int[] GetTouchValueX()
	{
		
		
		if(m_WebView != null)
		{
			
			int[] iValueX = new int[ m_WebView.m_eventSwap.size()];
			
			for(int i = 0; i < m_WebView.m_eventSwap.size(); i++)
			{
				MotionEvent event = m_WebView.m_eventSwap.get(i);
				iValueX[i] = (int)event.getX();
			}
			
			
			
			return iValueX;
			
		}
		
		return null;
		
	}
	public int[] GetTouchValueY()
	{
		
		
		if(m_WebView != null)
		{
			int[] iValueY = new int[ m_WebView.m_eventSwap.size()];
			
			for(int i = 0; i < m_WebView.m_eventSwap.size(); i++)
			{
				MotionEvent event = m_WebView.m_eventSwap.get(i);
				iValueY[i] = (int)event.getY();
			}
			
			
			
			return iValueY;
		}
		
		return null;
		
	}

	

	public void SetTouchValue( int[] iX, int[] iY,boolean[] bUse)
	{
		
		if(m_WebView != null)
		{
			m_WebView.m_bSync = true;
			m_WebView.m_bUse = new boolean[bUse.length];
			m_WebView.m_eventSelf.clear();
			for(int i = 0; i < m_WebView.m_eventSwap.size(); i++)
			{
				MotionEvent event = m_WebView.m_eventSwap.get(i);
				
				event.setLocation(iX[i],iY[i]);
				
				m_WebView.m_bUse[i] = bUse[i];
				m_WebView.m_eventSelf.add( event);
				
				
				
			}
		}
		
		
		m_UnityActivity.runOnUiThread(new Runnable() {public void run() {
			if(m_WebView != null)
			{
				
				for(int i = 0; i < m_WebView.m_eventSelf.size(); i++)
				{
					MotionEvent event = m_WebView.m_eventSelf.get(i);
					m_WebView.m_bTouch = true;
					if(m_WebView.m_bUse[i] == true)
						m_WebView.dispatchTouchEvent(event);
					m_WebView.m_bTouch = false;
				
				}
			}	
		}
		});
		
	}
	
	public void ClearTouchValue()
	{
		if(m_WebView != null)
		{
			m_UnityActivity.runOnUiThread(new Runnable() {public void run() {
				if(m_WebView != null)
				{
					m_WebView.m_bSync = false;
					m_WebView.m_eventSwap.clear();
				}
			}
			});
			
		}
		
	}
	
	public void StartConvertTouch()
	{
		
		
		
		if(m_WebView != null)
		{
			if( m_WebView.m_bSync == true)
				return;
			
			//m_WebView.m_bTouch = true;
			List<MotionEvent> listEvent =  m_WebView.m_event;
			
			m_WebView.m_event = m_WebView.m_eventSwap;
			m_WebView.m_eventSwap = listEvent;
		}
	}
	
	
	
	
 
 
 
 
 
}
